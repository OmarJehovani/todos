# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

modules = \
['todos']
setup_kwargs = {
    'name': 'todos',
    'version': '0.1.0',
    'description': 'Entregable del módulo 2, diplomado Despliegue de ML',
    'long_description': '# todos\nEntregable para el módulo 2\n',
    'author': 'Omar Jehovani López Orozco',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'package_dir': package_dir,
    'py_modules': modules,
    'python_requires': '==3.10.6',
}


setup(**setup_kwargs)
